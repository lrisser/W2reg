Please find different files to test the multi-class extension of W2reg on the Bios dataset (https://paperswithcode.com/dataset/biasbios). 


Note that the pipeline proposed here is not the same as the one made in the [Jourdan et al., Algorithm 2023] paper, although it was based on the same W2reg_core.py functions.


