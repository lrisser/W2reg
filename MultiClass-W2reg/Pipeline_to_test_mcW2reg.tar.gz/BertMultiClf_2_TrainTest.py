import pickle
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import random
import math
import copy
import io


import torch
import transformers
from torch.utils.data import Dataset, DataLoader
import torch.nn as nn
from transformers import DistilBertModel, DistilBertTokenizer
from sklearn import metrics
import re
from torch import cuda
device = 'cuda' if cuda.is_available() else 'cpu'


#device ='cpu'  #FOR DEBUGGING

print('Device is',device)

#+ + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + +
#1) get saved data
#+ + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + +
infile = open('./TreatedData_all5.pk','rb')
infile = open('./TreatedData_all5_neutral.pk','rb')
SavedData = pickle.load(infile)
infile.close()


X_test=SavedData["X_test"]
Masks_test=SavedData["Masks_test"]
y_test=SavedData["y_test"]
S_test=SavedData["g_test"]

X_train=SavedData["X_train"]
Masks_train=SavedData["Masks_train"]
y_train=SavedData["y_train"]
S_train=SavedData["g_train"]

del SavedData


#+ + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + +
#2) define the model
#+ + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + +


class DistillBERTClass(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.distill_bert = DistilBertModel.from_pretrained("distilbert-base-uncased")
        self.drop = torch.nn.Dropout(0.3)
        self.pre_out = torch.nn.Linear(768, 100)
        self.out = torch.nn.Linear(100, 28)

    def forward(self, ids, mask):
        distilbert_output = self.distill_bert(ids, mask)
        hidden_state = distilbert_output[0]  # (bs, seq_len, dim)
        pooled_output = hidden_state[:, 0]  # (bs, dim)
        output_1 = self.drop(pooled_output)
        output_2 = torch.relu(self.pre_out(output_1))
        output = torch.softmax(self.out(output_2),dim=1)
        return output



model = DistillBERTClass()
model.to(device)


#+ + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + +
#3) fit function
#+ + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + +


import sys

PATH_TO_W2REG_PACKAGE='./'

sys.path.append(PATH_TO_W2REG_PACKAGE)


from W2reg_core import *




#+ + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + +
#4) train
#+ + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + + +

tst_data={}
tst_data['known']=False


EPOCHS_NB=5

lambdavar=0.00108


Lists_Results=W2R_fit_NLP(model,X_train[:,:],Masks_train[:,:],y_train, S_train.numpy(), lambdavar , f_loss_attach=nn.BCELoss() , EPOCHS = EPOCHS_NB, BATCH_SIZE = 8,obs_for_histo=16,DEVICE=device,ID_TreatedVars=[[8,4.],[5,8.],[1,1.]],optim_lr=0.0000005,DistBetween='Predictions',test_data=tst_data)





plt.plot(Lists_Results['Loss'])
plt.savefig('l'+str(lambdavar)+'_convergence_Loss.pdf')  #show()
plt.clf()
plt.plot(Lists_Results['W2'])
plt.savefig('l'+str(lambdavar)+'_convergence_W2.pdf')  #show()
plt.clf()





